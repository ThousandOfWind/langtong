# config artifical memory here

#am = {
#     "设备id": [每半小时动作，],
# }
# 动作 in device.crafts.keys()+'wait'

def load_am_from_file(path):
    am = None
    return am

